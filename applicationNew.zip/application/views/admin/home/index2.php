<section>
    <div class="col-sm-12">
		<h1>Halaman Admin</h1>
        <!--<div class="page-header">
            <h4>Big Button</h4>
        </div>
        <section class="bigBtnIcon">
            <div class="col-md-3">
                <div class="label-col label-col-blue">
                    <a href="#">
                        <span class="icon icomoon-icon-support"></span>
                        <span class="txt">Support tickets</span>
                        <span class="notification">125</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="label-col label-col-green">
                    <a href="#">
                        <span class="icon icomoon-icon-users"></span>
                        <span class="txt">All Active Article</span>
                        <span class="notification">42036</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="label-col label-col-red">
                    <a href="#">
                        <span class="icon icomoon-icon-bubbles-2"></span>
                        <span class="txt">Article This Month</span>
                        <span class="notification">1225</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="label-col label-col-yellow">
                    <a href="#">
                        <span class="icon icomoon-icon-users"></span>
                        <span class="txt">User Jawaban</span>
                        <span class="notification">125</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="label-col label-col-purple">
                    <a href="#">
                        <span class="icon icomoon-icon-users"></span>
                        <span class="txt">User Jawaban</span>
                        <span class="notification">125</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="label-col label-col-orange">
                    <a href="#">
                        <span class="icon icomoon-icon-users"></span>
                        <span class="txt">User Jawaban</span>
                        <span class="notification">125</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="label-col label-col-grey">
                    <a href="#">
                        <span class="icon icomoon-icon-users"></span>
                        <span class="txt">User Jawaban</span>
                        <span class="notification">125</span>
                    </a>
                </div>
            </div>
        </section>
    </div>
</section>
<?php $this->load->view('admin/samples/icon'); ?>
<?php $this->load->view('admin/samples/table'); ?>
<?php $this->load->view('admin/samples/form'); ?>
<div class="col-lg-6">
    <div class="page-header">
        <h4>Regular tabs</h4>
    </div>
    <div style="margin-bottom: 20px;">
        <ul id="myTab" class="nav nav-tabs pattern">
            <li class="active"><a href="#home" data-toggle="tab">Home</a></li>
            <li><a href="#profile" data-toggle="tab">Profile</a></li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="#dropdown1" data-toggle="tab">@fat</a></li>
                    <li><a href="#dropdown2" data-toggle="tab">@mdo</a></li>
                </ul>
            </li>
        </ul>

        <div class="tab-content">
            <div class="tab-pane fade in active" id="home">
                <p>Raw denim you probably haven't heard of them jean shorts Austin. </p>
            </div>
            <div class="tab-pane fade" id="profile">
                <p>Food truck fixie locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid. </p>
            </div>
            <div class="tab-pane fade" id="dropdown1">
                <p>Etsy mixtape wayfarers, ethical wes anderson tofu before they sold out mcsweeney's organic lomo retro fanny pack lo-fi farm-to-table readymade. </p>
            </div>
            <div class="tab-pane fade" id="dropdown2">
                <p>Trust fund seitan letterpress, keytar raw denim keffiyeh etsy art party before they sold out master.</p>
            </div>
        </div>
    </div>

    <div class="page-header">
        <h4>Accordion</h4>
    </div>

    <div class="panel-group accordion gradient" id="accordion">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseAccOne">
                        Collapsible Group Item #1
                    </a>
                </h4>
            </div>
            <div id="collapseAccOne" class="panel-collapse collapse in">
                <div class="panel-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseAccTwo">
                        Collapsible Group Item #2
                    </a>
                </h4>
            </div>
            <div id="collapseAccTwo" class="panel-collapse collapse">
                <div class="panel-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseAccThree">
                        Collapsible Group Item #3
                    </a>
                </h4>
            </div>
            <div id="collapseAccThree" class="panel-collapse collapse">
                <div class="panel-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
    </div>
    <div class="page-header">
        <h4>Static alert messages</h4>
    </div>

    <div class="alert alert-warning">
        <button class="close" data-dismiss="alert">&times;</button>
        <strong>Warning!</strong> Best check yo self, you're not looking too good.
    </div>

    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Oh snap!</strong> Change a few things up and try submitting again.
    </div>

    <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Well done!</strong> You successfully read this important alert message.
    </div>

    <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Heads up!</strong> This alert needs your attention, but it's not super important.
    </div>

    <div class="alert alert-block alert-danger fade in">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <h4 class="alert-heading">Oh snap! You got an error!</h4>
        <p>Change this and that and try again. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Cras mattis consectetur purus sit amet fermentum.</p>
        <p>
            <a class="btn btn-danger" href="#">Take this action</a> <a class="btn" href="#">Or do this</a>
        </p>
    </div>
</div>
<div class="col-lg-6">
    <div class="page-header">
        <h4>Pagination</h4>
    </div>
    <div class="center">
        <ul class="pagination">
            <li><a href="#">&larr;</a></li>
            <li class="active">
                <a href="#">1</a>
            </li>
            <li><span>...</span></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">&rarr;</a></li>
        </ul>                                        
    </div>

    <section>
        <div class="col-sm-12">
            <div class="page-header">
                <h4>Pager</h4>
            </div>

            <ul class="pager">
                <li>
                    <a href="#">Previous</a>
                </li>
                <li>
                    <a href="#">Next</a>
                </li>
            </ul>
        </div>
    </section>

    <section>
        <div class="col-sm-12">
            <div class="page-header">
                <h4>Pager with aligned links</h4>
            </div>

            <ul class="pager">
                <li class="previous">
                    <a href="#">&larr; Older</a>
                </li>
                <li class="next">
                    <a href="#">Newer &rarr;</a>
                </li>
            </ul>
        </div>-->
    </section>

</div> 

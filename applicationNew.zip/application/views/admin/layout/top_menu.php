<div class="navigation">
    <h4>
        <?php echo $page_title; ?>
    </h4>
</div>
<ul class="breadcrumb hidden-lg hidden-md hidden-sm">
    <li><a href="#"><span class="icon16 icomoon-icon-screen-2"></span></a><span class="divider"><span class="icon16 icomoon-icon-arrow-right-3"></span></span></li>
    <li class="active">Dashboard</li>
</ul>
<div id="page-wrapper">
<?php echo $page; ?>
</div>
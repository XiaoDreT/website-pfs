<?php $this->load->view('latest/layout/navigation') ?>
<div class="inner-page about-us">
    <div class="container">
        <div class="tblack">
            <div class="col-md-12">
                <h2>About Us</h2>
                <p><?php echo $rec_data->detail; ?></p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<div class="inner-head">
    <div class="container">
        <div class="col-lg-12">
            <h4 class="pull-left" style="text-transform: capitalize;"><?php echo $menu['name']; ?></h4>
            <p class="pull-right pagination"><a style="color: white" href="<?php echo site_url('latest/home'); ?>">Home</a><span>></span><a style="color: white" href="<?php echo $menu['link']; ?>"><?php echo $menu['name']; ?></a></p>
        </div>
    </div>
</div>
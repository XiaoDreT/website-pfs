<div class="inner-head">

    <div class="container">

        <div class="col-lg-12">

            <h4 class="pull-left"><?php echo $menu['name']; ?></h4>

            <p class="pull-right pagination"><a href="<?php echo site_url('old/home'); ?>">Home</a><span>></span><a href="<?php echo $menu['link']; ?>"><?php echo $menu['name']; ?></a></p>

        </div>

    </div>

</div>